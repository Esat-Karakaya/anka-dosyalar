Bilinen hatalar:
* dizayn -> tasarım çevrimi yapılırken "dizayn et" -> "tasarım et" olur
* Link-> Bağlantı çevrimi yapılırken LinkedIn -> BağlantıedIn olur
* Uzantıları yönet sayfasında logo gözükmüyor
* mı, mi, mu, mü soru ekleri değiştirilmiyor
* ikiden fazla kelimeden oluşan "dizayn ede ede" gibi kelimelerin sadece ilk ikisine bakılıyor
* dizayn ve perspektif kelimesi doğrudan değiştirilirse düzeltilen kelime sayısı fazladan hesaplanıyor
* önerilen kelime sayısı tutulmuyor

Geliştirilebilir yerler:
* Site-fix ve auto-fix yabancı kelimeyi sadece tek bir kelimeyle çevirir. Ancak eklenti yine de olabilecek tüm hesaplamaları yaparak gereksiz işlem yapar
* düzeltme penceresi kısayol ile yapılabilir
* sayfa için düzeltme düğmesi ve onun açılma kısayolu yapılabilir
* doğrulama düğmesi sayfanın alt köşesinde bulunabilir