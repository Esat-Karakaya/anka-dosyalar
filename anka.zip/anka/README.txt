Bilinen hatalar:
* dizayn -> tasarım çevrimi yapılırken "dizayn et" -> "tasarım et" olur
* Link-> Bağlantı çevrimi yapılırken LinkedIn -> BağlantıedIn olur
* Uzantıları yönet sayfasında logo gözükmüyor

Geliştirilebilir yerler:
* Site-fix ve auto-fix yabancı kelimeyi sadece tek bir kelimeyle çevirir. Ancak eklenti yine de olabilecek tüm hesaplamaları yaparak gereksiz işlem yapar
* Site-fix recursive bir şekilde sadece belirtilen taglara girer, bu custom taglara girememesine neden olur. querySelector kullanılabilir.
* Safari desteği yok
* çoğu yabancı kelimenin tüm karşılıkları yok